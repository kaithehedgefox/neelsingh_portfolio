"use strict";

/*
   New Perspectives on HTML5 and CSS3, 7th Edition
   Tutorial 10
   Case Problem 1

   Author: Neel Singh
   Date: 4-24-19  
   
   Filename: tc_cart.js
	
*/

