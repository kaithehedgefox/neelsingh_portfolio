
"use strict";

/*
   New Perspectives on HTML5 and CSS3, 7th Edition
   Tutorial 9
   Review Assignment

   Event Timer
   Author: Neel Singh
   Date: 3-27-19 

*/

function showClock()
setInterval("showClock()", 1000);


function runClock() {
    var thisDay = new Date();
    var localDate = currentDay.toLocaleDateString();
    var localTime = currentDay.toLocaleTimeString();
}

function nextJuly4(thisDay) {
    
    /* Calculate the days until July 4th */
   var cYear = currentDate.getFullYear();
   var jDate = new Date("July 4, 2018");
   jDate.setFullYear(cYear);
   if ((jDate - thisDay) < 0) jDate.setFullYear(cYear + 1);
   jDate.setHours(21:00:00); 
   return jDate;
    
var days = (Jdate - ThisDay)/(1000*60*60*24);

var hrs = (daysLeft - Math.floor(daysLeft))*24;

var mins = (hrsLeft - Math.floor(hrsLeft))*60;
var secs = (hrsLeft - Math.floor(minsLeft))*60;
}